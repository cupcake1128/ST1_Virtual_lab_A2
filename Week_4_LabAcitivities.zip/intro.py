#intro.py
from PIL import Image
# create an image via import
image = Image.open('1_Gammar 2021_1_2021_06_03-13-19-23-879.png')
image.show()

# analyze the image
print(image.size)
print(image.filename)
print(image.format)
# # flip the image
image_flipped = image.transpose(Image.Transpose.ROTATE_90)
# # show the image
image_flipped.show()
# exercise
img_rotated = image.rotate(30)
img_rotated.save('img_rotated.png', 'png')
img_rotated.show()